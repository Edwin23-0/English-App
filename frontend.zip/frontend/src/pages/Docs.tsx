const Docs: React.FC = () => {
    return (
        <div>
            <h1>Docs Page</h1>
            <p>Welcome to the documentation section of English App.</p>
        </div>
    );
};

export default Docs;
