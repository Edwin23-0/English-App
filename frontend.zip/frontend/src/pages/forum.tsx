const Forum: React.FC = () => {
    return (
        <div>
            <h1>Forum Page</h1>
            <p>Discuss and share ideas with the community.</p>
        </div>
    );
};

export default Forum;
