from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()  # Instancia de SQLAlchemy
